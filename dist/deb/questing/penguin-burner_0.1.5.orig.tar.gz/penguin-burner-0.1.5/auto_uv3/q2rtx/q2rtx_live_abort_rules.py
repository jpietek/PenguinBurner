"""Abort a live Q2RTX/CUDA probe only on strong instability evidence.

Rules cover invalid timedemo output, FPS collapse, lost load, low clocks, and stalled progress.
"""

from __future__ import annotations

from ..auto_uv_user_options import (
    AUTO_UV_CURVE_TUNING,
    AUTO_UV_METRIC_TUNING,
    AUTO_UV_STALL_TUNING,
)
from .probe_runtime_guardrails import core_clock_below_floor, telemetry_sample_is_busy
from .q2rtx_probe_summary import mean


def timedemo_live_abort_reason(
    state: dict,
    *,
    frame_reference: int | None,
    proper_run_fps_floor: float | None,
    progress_state: dict,
) -> str | None:
    frame_ref = frame_reference or state.get("expected_frames_per_run")
    for run in list(state.get("new_timedemo_runs") or []):
        frames, seconds, fps = int(run.frames), float(run.seconds), float(run.fps)
        if frames <= 0 or seconds <= 0.0 or fps <= 0.0:
            return "timedemo-metrics-invalid"
        if frame_ref is not None and frames != int(frame_ref):
            return (
                f"timedemo-live-frame-count current={frames} "
                f"expected={int(frame_ref)} run={int(run.run_index)}"
            )
        if proper_run_fps_floor is None or int(run.run_index) <= 1:
            progress_state["low_fps_streak"] = 0
            continue
        progress_state["low_fps_streak"] = (
            int(progress_state.get("low_fps_streak", 0)) + 1
            if fps < float(proper_run_fps_floor)
            else 0
        )
        if (
            int(progress_state["low_fps_streak"])
            >= AUTO_UV_METRIC_TUNING.min_proper_run_fps_regression_streak
        ):
            return (
                f"timedemo-live-fps-regression current={fps:.1f} "
                f"floor={float(proper_run_fps_floor):.1f} "
                f"margin={AUTO_UV_METRIC_TUNING.min_proper_run_fps_pct:.1f}% "
                f"streak={int(progress_state['low_fps_streak'])} "
                f"run={int(run.run_index)}"
            )
    return None


def telemetry_live_abort_reason(
    state: dict,
    *,
    busy_power_floor_w: float | None,
    proper_run_power_floor_w: float | None,
    target_core_clock_floor_mhz: float | None,
    progress_state: dict,
) -> str | None:
    samples = list(state.get("telemetry_samples") or [])
    busy_samples = [s for s in samples if telemetry_sample_is_busy(s, busy_power_floor_w)]
    clocks = [
        float(sample.core_clock_mhz)
        for sample in busy_samples
        if sample is not None and sample.core_clock_mhz is not None
    ]
    latest = state.get("latest_sample")
    latest_busy = telemetry_sample_is_busy(latest, busy_power_floor_w)
    lost = load_lost_abort_reason(
        state,
        latest_sample=latest,
        proper_run_power_floor_w=proper_run_power_floor_w,
        busy_power_floor_w=busy_power_floor_w,
        live_sample_is_busy=latest_busy,
        progress_state=progress_state,
    )
    if lost is not None:
        return lost
    live_clock = (
        float(latest.core_clock_mhz)
        if latest is not None and latest.core_clock_mhz is not None
        else None
    )
    low_live = low_live_clock_abort_reason(
        live_core_clock_mhz=live_clock,
        live_sample_is_busy=latest_busy,
        core_clock_samples=clocks,
        target_core_clock_floor_mhz=target_core_clock_floor_mhz,
        progress_state=progress_state,
    )
    if low_live is not None:
        return low_live
    avg_clock = mean(clocks)
    if (
        target_core_clock_floor_mhz is not None
        and avg_clock is not None
        and len(clocks) >= AUTO_UV_STALL_TUNING.avg_core_clock_abort_min_samples
        and core_clock_below_floor(avg_clock, target_core_clock_floor_mhz)
    ):
        return (
            f"telemetry-live-core_clock-avg current={avg_clock:.1f}MHz "
            f"floor={target_core_clock_floor_mhz:.1f}MHz "
            f"tolerance={AUTO_UV_CURVE_TUNING.clock_select_tolerance_mhz:.1f}MHz"
        )
    return None


def load_lost_abort_reason(
    state: dict,
    *,
    latest_sample,
    proper_run_power_floor_w: float | None,
    busy_power_floor_w: float | None,
    live_sample_is_busy: bool,
    progress_state: dict,
) -> str | None:
    if (
        proper_run_power_floor_w is None
        or latest_sample is None
        or latest_sample.power_w is None
        or len(list(state.get("telemetry_samples") or []))
        < AUTO_UV_STALL_TUNING.live_core_clock_abort_min_samples
        or float(state.get("elapsed_s", 0.0))
        < float(AUTO_UV_METRIC_TUNING.loaded_sample_warmup_s)
    ):
        return None
    progress_state["low_power_streak"] = (
        int(progress_state.get("low_power_streak", 0)) + 1
        if not live_sample_is_busy
        and float(latest_sample.power_w) < float(proper_run_power_floor_w)
        else 0
    )
    if (
        int(progress_state["low_power_streak"])
        < AUTO_UV_METRIC_TUNING.target_core_clock_low_streak_samples
    ):
        return None
    busy_text = (
        f"{float(busy_power_floor_w):.1f}W"
        if busy_power_floor_w is not None
        else "n/a"
    )
    return (
        f"telemetry-live-load-lost current={float(latest_sample.power_w):.1f}W "
        f"floor={float(proper_run_power_floor_w):.1f}W "
        f"busy-floor={busy_text} "
        f"load-floor={AUTO_UV_METRIC_TUNING.min_proper_run_power_pct:.1f}%"
    )


def low_live_clock_abort_reason(
    *,
    live_core_clock_mhz: float | None,
    live_sample_is_busy: bool,
    core_clock_samples: list[float],
    target_core_clock_floor_mhz: float | None,
    progress_state: dict,
) -> str | None:
    if (
        target_core_clock_floor_mhz is None
        or live_core_clock_mhz is None
        or len(core_clock_samples) < AUTO_UV_STALL_TUNING.live_core_clock_abort_min_samples
    ):
        return None
    progress_state["low_core_clock_streak"] = (
        int(progress_state.get("low_core_clock_streak", 0)) + 1
        if live_sample_is_busy
        and core_clock_below_floor(live_core_clock_mhz, target_core_clock_floor_mhz)
        else 0
    )
    if (
        int(progress_state["low_core_clock_streak"])
        < AUTO_UV_METRIC_TUNING.target_core_clock_low_streak_samples
    ):
        return None
    return (
        f"telemetry-live-core_clock current={live_core_clock_mhz:.1f}MHz "
        f"floor={target_core_clock_floor_mhz:.1f}MHz "
        f"tolerance={AUTO_UV_CURVE_TUNING.clock_select_tolerance_mhz:.1f}MHz"
    )


def timedemo_stall_abort_reason(
    state: dict,
    *,
    busy_power_floor_w: float | None,
    expected_loop_s: float | None,
    last_progress_elapsed_s: float,
) -> str | None:
    if expected_loop_s is None or int(state.get("completed_runs", 0)) <= 0:
        return None
    idle_s = float(state.get("elapsed_s", 0.0)) - float(last_progress_elapsed_s)
    stall_s = max(
        AUTO_UV_STALL_TUNING.timeout_min_s,
        float(expected_loop_s) * AUTO_UV_STALL_TUNING.timeout_multiplier,
    )
    if idle_s <= stall_s:
        return None
    latest = state.get("latest_sample")
    gpu_util = getattr(latest, "gpu_util_pct", None) if latest is not None else None
    power_w = getattr(latest, "power_w", None) if latest is not None else None
    gpu_busy = (
        gpu_util is not None and float(gpu_util) >= AUTO_UV_STALL_TUNING.busy_gpu_util_pct
    ) or (
        power_w is not None
        and busy_power_floor_w is not None
        and float(power_w) >= float(busy_power_floor_w)
    )
    if gpu_busy:
        return None
    return (
        f"timedemo-live-stall idle={idle_s:.1f}s "
        f"stall={stall_s:.1f}s completed={int(state.get('completed_runs', 0))}"
    )
